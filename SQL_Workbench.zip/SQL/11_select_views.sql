/*view escola e secretaria*/
select * from e_escola;
select * from s_secretaria;

/*view aluno*/
select * from a_aluno;
select * from a_aluno_crescente;
select * from a_aluno_decrescente;
select * from a_matricula_crescente;
select * from a_matricula_decrescente;

/*view boletim */
select * from b_boletim;
select * from b_aprovados;
select * from b_recuperacao;
select * from b_reprovados;
select * from b_orderby_aprovados;
select * from b_orderby_reprovados;

/*view estoque */
select * from es_estoque;
select * from es_funcio_crescente;
select * from es_funcio_crescente;
select * from es_menor30;

/*view planejamento */
select * from p_planejamento;
select * from p_crescente_professor;

/*view funcionarios */
select * from f_funcionarios;
select * from f_carga_horaria;
select * from f_crescente;
select * from f_decrescente;
select * from f_matutino;
select * from f_comercial;
select * from f_noturno;





 